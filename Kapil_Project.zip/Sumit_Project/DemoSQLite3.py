from tkinter import *
from tkinter.filedialog import askopenfilename
import sqlite3 as sq
import pandas as pd
# GUI for browse button
class GUIImport:
    def __init__(self,master):
        self.filename = ' '
        #Browse Bar
        csvfile=Label(root, text="File").grid(row=1, column=0)
        bar=Entry(master).grid(row=1, column=1) 
        #Buttons  
        y=7
        self.cbutton= Button(root, text="OK", command=master.destroy)       #closes window
        y+=1
        self.cbutton.grid(row=10, column=3, sticky = W + E)
        self.ebutton = Button(root, text="Submit", command=master.quit)
        self.ebutton.grid(row=10, column=1, sticky = W + E)
        self.bbutton= Button(root, text="Browse", command=self.browsecsv)
        self.bbutton.grid(row=1, column=3)
# function to get path name
    def browsecsv(self):
        #from self.filedialog import askopenfilename
        Tk().withdraw() 
        filename = askopenfilename()
        print(filename) #debug statement
        self.filename = filename
        #print(type(filename))
class AppBegin:
    #conn
    #xl
    def __init__(self,fn,db):
        self.datai = 0
        self.datau = 0
# opening database connection
        self.conn = sq.connect(db)
# opening excel file with path
        self.xl = pd.read_excel(fn)
    def reading(self):
# fetching data row by row
        xl2 = self.xl.set_index("S.No.") #setting index on the data frame
        prime = self.xl.loc[:,"S.No."]   #generating list based on unique id
        # Getting each row based upon the unique id
        for i in prime:
            row1 = xl2.loc[i,:]
            self.data_table(i,row1,self.conn)
            # print(i,end = ' ') Debugging Step 
            # print(row1["College"]) Debugging Step
        self.comit_data(self.conn)
        print('data commited to the table')
        self.closing(self.conn)
        print('data connection closed')
        print('Number of Records inserted ', self.datai)
        print('Number of Records updated ', self.datau)
    def data_table(self,key,value_dict,master):
# inserting/update data into a table based on try and except
        c = master.cursor()
        value_l = [key,value_dict["College"],value_dict["Course"],value_dict["Specialisation"]]
        value_l_r = [value_dict["College"],value_dict["Course"],value_dict["Specialisation"],key]
        try:
            c.execute('INSERT INTO COLLEGE_LIST VALUES(?,?,?,?,DateTime("now"),DateTime("now"))',value_l)
            self.datai += 1
        except:
            c.execute('UPDATE COLLEGE_LIST SET College = ?,Course = ?,Specialisation = ?,Last_update_date = DateTime("now") WHERE ID=?',value_l_r)
            self.datau += 1
    def comit_data(self,master):
# commiting data into tables
        master.commit()
    def closing(self,master):
# closing database connection
        master.close()
# Calling everything here :
if __name__ == "__main__":   
    root = Tk()
    window=GUIImport(root)
    root.mainloop()
    print(window.filename)
    AppB = AppBegin(window.filename,'Example.db')
    AppB.reading()
    # xl = pd.read_excel(window.filename, header = None)
    # print(xl)
